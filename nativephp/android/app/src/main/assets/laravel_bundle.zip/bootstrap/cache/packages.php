<?php return array (
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/flux' => 
  array (
    'aliases' => 
    array (
      'Flux' => 'Flux\\Flux',
    ),
    'providers' => 
    array (
      0 => 'Flux\\FluxServiceProvider',
    ),
  ),
  'livewire/flux-pro' => 
  array (
    'aliases' => 
    array (
      'Flux' => 'FluxPro\\FluxPro',
    ),
    'providers' => 
    array (
      0 => 'FluxPro\\FluxProServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'livewire/volt' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\Volt\\VoltServiceProvider',
    ),
  ),
  'nativephp/mobile' => 
  array (
    'providers' => 
    array (
      0 => 'Native\\Mobile\\NativeServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
);